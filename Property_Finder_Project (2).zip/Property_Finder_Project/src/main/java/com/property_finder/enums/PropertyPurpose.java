package com.property_finder.enums;

public enum PropertyPurpose {
RENT,SELL
};
