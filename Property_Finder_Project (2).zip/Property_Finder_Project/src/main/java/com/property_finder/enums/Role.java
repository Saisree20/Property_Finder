package com.property_finder.enums;

public enum Role {
	CUSTOMER,OWNER
};
