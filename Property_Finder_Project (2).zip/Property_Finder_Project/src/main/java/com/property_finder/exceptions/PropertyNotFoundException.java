package com.property_finder.exceptions;

public class PropertyNotFoundException extends Exception {

	public PropertyNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
