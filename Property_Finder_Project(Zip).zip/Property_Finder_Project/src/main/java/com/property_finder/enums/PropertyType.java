package com.property_finder.enums;

public enum PropertyType {
RESIDENTIAL,COMMERCIAL
};
