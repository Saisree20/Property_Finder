package com.property_finder.exceptions;

public class InvalidCredentialsException extends Exception {

	public InvalidCredentialsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
