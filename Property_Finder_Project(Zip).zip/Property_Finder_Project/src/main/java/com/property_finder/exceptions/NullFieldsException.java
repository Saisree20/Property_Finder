package com.property_finder.exceptions;

public class NullFieldsException extends Exception{

	public NullFieldsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
